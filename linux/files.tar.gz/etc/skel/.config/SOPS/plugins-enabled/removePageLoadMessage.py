#!/bin/python

from orca import messages

messages.PAGE_LOADING_END = ''
messages.PAGE_LOADING_END_NAMED = ''
messages.PAGE_LOADING_START = ''
