#!/bin/sh
while true;do
if ps -e|grep -q speechd-up.bin;then
sleep .01
else
speechd-up.bin $@
fi
done
exit 0
