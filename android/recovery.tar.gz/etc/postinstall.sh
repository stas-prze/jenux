#!/bin/zsh
mount -t proc /proc /proc
mount -t devtmpfs /dev /dev
mount -t sysfs /sys /sys
mount -t efivarfs /sys/firmware/efi/efivars /sys/firmware/efi/efivars
if [ -f /boot.old.tar.gz ];then
echo restoring old ESP content
cd /boot
tar -xf /boot.old.tar.gz
fi
read disk </disk
usermod -s /bin/zsh root
locale-gen
grub-install --target i386-pc $disk
grub-install --efi-directory /boot --target i386-efi $disk
grub-install --efi-directory /boot --target x86_64-efi $disk
mv /boot/EFI/arch/ /boot/EFI/boot
mv /boot/EFI/boot/grubia32.efi /boot/EFI/boot/bootia32.efi
mv /boot/EFI/boot/grubx64.efi /boot/EFI/boot/loader.efi
cp /usr/share/preloader-signed/HashTool.efi  /boot/EFI/boot
cp /usr/share/preloader-signed/PreLoader.efi  /boot/EFI/boot/bootx64.efi
for f in "1" "2" "3" "4" "5" "6";do
systemctl enable getty@tty$f > /dev/null 2>/dev/null
done
echo "installing android... "
iso2access /android.iso $disk
rm /etc/postinstall.sh
umount /sys/firmware/efi/efivars /sys /dev /proc
exit 0
