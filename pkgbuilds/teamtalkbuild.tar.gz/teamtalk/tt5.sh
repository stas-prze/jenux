#!/bin/sh
if [ -d $HOME/.tt5 ];then
sleep .01
else
mkdir -p ~/.tt5
cp -rf /usr/share/teamtalk5/* ~/.tt5
fi
cd ~/.tt5
teamtalk5
exit
