#!/bin/bash

# Displays the current version of orca.
# License WTFPL: http://wtfpl.net

version="orca $(orca -v 2> /dev/null)"
if command -v xclip &> /dev/null ; then
echo "$version" | xclip -selection clipboard 2> /dev/null
fi
echo "$version"
exit 0
