Thank you for contributing to **AlexaPi**.

**Issue this PR fixes (if applicable):** #

**Description:**

**Checklist:**
  - [ ] Update CHANGELOG.md
  - [ ] Update Wiki (new platform, installation, configuration changes etc)
  - [ ] PR Location (usually `master` for hotfixes, `dev` for general development)
