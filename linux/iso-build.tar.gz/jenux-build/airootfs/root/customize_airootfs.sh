#!/bin/bash
set -e -u

sed -i 's/#\(en_US\.UTF-8\)/\1/' /etc/locale.gen
locale-gen

ln -sf /usr/share/zoneinfo/UTC /etc/localtime

usermod -s /usr/bin/zsh root
cp -aT /etc/skel/ /root/
cp /root/NetworkManager.service /usr/lib/systemd/system/
cp /root/polkit.service /usr/lib/systemd/system
rm /root/NetworkManager.service
rm /root/polkit.service
systemctl disable netctl.service netctl-sleep.service netctl-ifplugd\@.service netctl-auto\@.service systemd-networkd.socket systemd-networkd.service systemd-networkd-wait-online.service xl2tpd.service dhcpcd.service dhcpcd\@.service dhclient\@.service
systemctl enable wpa_supplicant.service wpa_supplicant-nl80211\@.service wpa_supplicant-wired\@.service wpa_supplicant.service wpa_supplicant\@.service
chmod 700 /root

sed -i "s/#Server/Server/g" /etc/pacman.d/mirrorlist
sed -i "s/# Server/Server/g" /etc/pacman.d/blackarch-mirrorlist
sed -i 's/#\(Storage=\)auto/\1volatile/' /etc/systemd/journald.conf
systemctl enable NetworkManager.service polkit.service sshcheck.service wifiinit.service haveged.service
while true;do
if curl -Lo /etc/pacman.conf https://nashcentral.duckdns.org/autobuildres/linux/pacman.conf;then
break
else
continue
fi
done
