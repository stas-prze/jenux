#!/bin/sh
spd-say " "
socat -d TCP-LISTEN:6560,fork UNIX:/run/user/`id -u`/speech-dispatcher/speechd.sock < /dev/null 2> /dev/null&sleep .01
/usr/bin/yasr.bin $@
killall socat
