#!/bin/bash

# shellcheck disable=SC2034
DESCRIPTION="Integrating with Magic Mirror project (MMM-AlexaPi)"

function install_device {
    :
}

function install_device_config {
    config_set 'device' 'magicmirror'
}
