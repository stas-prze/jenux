sed -i s/Architecture\ \=\ auto/Architecture\ \=\ $1/g /etc/pacman.conf
if [ -f /bin/sudo ];then
sleep .01
else
echo installing software...
if [ -f /usr/share/pacman/keyrings/blackarch-trusted ];then
sleep .01
else
curl -o /strap.sh https://blackarch.org/strap.sh
chmod 755 /strap.sh
while true;do
if pacman-key --init;/strap.sh;pacman-key --populate archlinuxarm blackarch;pacman -Syy;then
rm /strap.sh
break
else
continue
fi
done
fi
echo searching for missing packages
cp initpkgs.$2 install
cat initpkgs.$2 |tr \  \\n|pacman --print-format %n -Sp - 2>/dev/stdout|grep -i 'target not found'|cut -f 3 -d : > missing
if wc -c missing |cut -f 1 -d \  |grep -qw 0;then
sleep .01
else
for f in `cat missing`;do
echo removing $f package, not in arm repos
sed -i s\|\ $f\ \|\ \|g install
done
fi
echo "installing software"
while true;do
sed -i s/CheckSpace/#CheckSpace/g /etc/pacman.conf
if cat install|tr \  \\n|pacman --needed --noconfirm --overwrite \* -Syu -;then
rm initpkgs.* install missing
sed -i s/#CheckSpace/CheckSpace/g /etc/pacman.conf
break
else
continue
fi
done
fi
case "$2" in
alexa)
export services=`echo -n NetworkManager sshd`
useradd -m -s /bin/bash alexa
usermod -a -G wheel,audio,video,storage alexa
echo enter a password for the alexa user account. This can be change with the passwd command from your ssh console. 
passwd alexa
echo setting permissions...
chown -R alexa:alexa /home/alexa
echo test_mode\=5 >> /boot/config.txt
;;
jenux)
systemctl disable haveged systemd-networkd
if cat /proc/cmdline|grep -qw nospeech;then
export services=('avahi-daemon bluetooth brcm43438 btconnect ModemManager NetworkManager rngd systemd-timesyncd')
else
export services=('avahi-daemon bluetooth brcm43438 btconnect fenrirscreenreader ModemManager NetworkManager rngd speech-dispatcherd systemd-timesyncd')
fi
while true;do
echo enter your user name
read user
if useradd -m -s /bin/zsh $user;then
break
else
echo error adding user, please re-enter your user name
continue
fi
done
usermod -a -G wheel,audio,video,network,optical,storage $user
echo enter a password that you will use to log in.
while true;do
if passwd $user;then
break
else
echo error setting user password, please re-enter your user password
continue
fi
done
chown -R gdm:gdm /var/lib/gdm
;;
kodi)
export services=`echo -n avahi-daemon bluetooth kodi NetworkManager sshd`
rm -rf /var/lib/kodi/.kodi /home/alexa /usr/bin/alexa /etc/systemd/system/getty@tty1.service.d/alexa.conf
echo enter a password for your kodi user account. This can be changed later from your ssh console with the "passwd" command. This user will have administrative access to this system by default, so please make it difficult to guess.
passwd kodi
echo setting group ownership...
usermod -a -G wheel,audio,video,network,storage,optical,kodi kodi
echo setting kodi user to use bash as login shell...
usermod -s /bin/bash kodi
factory-reset
;;
esac
echo enabling members of wheel group to use sudo...
sed -i s/'# %wheel ALL=(ALL) ALL'/'%wheel ALL=(ALL) ALL'/g /etc/sudoers
echo enabling services
for s in `echo $services`;do
if [ -e /lib/systemd/system/$s.service ];then
systemctl enable $s
fi
done
echo enabling audio on boot
echo dtparam=audio=on >> /boot/config.txt
echo hdmi_group=2 >> /boot/config.txt
echo hdmi_mode=82 >> /boot/config.txt
userdel alarm
rm -rf /home/alarm
for f in "/usr/bin/qemu-aarch64-static" "/usr/bin/qemu-arm-static";do
if [ -f $f ];then
rm $f
fi
done
rm /etc/postinstall.sh
exit
