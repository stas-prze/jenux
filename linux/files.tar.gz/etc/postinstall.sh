#!/bin/zsh
mount -t proc /proc /proc
mount -t devtmpfs /dev /dev
mount -t sysfs /sys /sys
mount -t efivarfs /sys/firmware/efi/efivars /sys/firmware/efi/efivars
if [ -f /boot.old.tar.gz ];then
echo restoring old ESP content
cd /boot
tar -xf /boot.old.tar.gz
fi
passwd -l root
if cat /proc/cmdline|grep -q nospeech; then
rm -rf /etc/skel/.config/autostart/orca.desktop /etc/skel/.config/retroarch.accessibility /etc/skel/.zlogin.accessibility /etc/skel/.profile.accessibility /etc/skel/.kodi/addons/service.xbmc.tts /usr/share/origprofile/kodi/.kodi/addons/service.xbmc.tts /var/lib/gdm/.config/dconf/user
case "$2" in
base)
if [ $3 = y ];then
export services=`echo "avahi-daemon bluetooth NetworkManager ntpd swap wifiinit"`
else
export services=`echo "avahi-daemon bluetooth NetworkManager ntpd wifiinit"`
fi
for f in "/etc/skel/.zlogin" "/etc/skel/.profile";do
cat > $f <<EOF
source /etc/profile.d/*.sh
umask 077
export GTK_MODULES=gail:atk-bridge
export QT_ACCESSIBILITY=1
export DTK_PROGRAM=espeak
export PATH=$PATH:/opt/android-sdk/platform-tools:/usr/bin/core_perl:~/bin
EOF
done
;;
gnome)
if [ $3 = y ];then
export services=`echo "avahi-daemon bluetooth cups-browsed gdm ModemManager NetworkManager org.cups.cupsd swap systemd-timesyncd wifiinit"`
else
export services=`echo "avahi-daemon bluetooth cups-browsed gdm ModemManager NetworkManager org.cups.cupsd systemd-timesyncd wifiinit"`
fi
;;
mate)
if [ $3 = y ];then
export services=`echo "avahi-daemon bluetooth NetworkManager ntpd swap wifiinit"`
else
export services=`echo "avahi-daemon bluetooth NetworkManager ntpd wifiinit"`
fi
for f in "/etc/skel/.zlogin" "/etc/skel/.profile";do
cat > $f <<EOF
source /etc/profile.d/*.sh
umask 077
export GTK_MODULES=gail:atk-bridge
export QT_ACCESSIBILITY=1
export DTK_PROGRAM=espeak
export PATH=$PATH:/opt/android-sdk/platform-tools:/usr/bin/core_perl:~/bin
if [ -f jenux.defaults ];then
dbus-launch gsettings set org.mate.interface accessibility true
cat jenux.defaults|dconf load /
rm jenux.defaults
else
sleep .01
fi
if is-x-running;then
sleep .01
else
startx
logout
fi
EOF
done
;;
kodi)
export nouser=1
if [ $3 = y ];then
export services=`echo "avahi-daemon kodi NetworkManager ntpd sshd swap wifiinit wpa_supplicant"`
else
export services=`echo "avahi-daemon kodi NetworkManager sshd ntpd sshd wifiinit wpa_supplicant"`
fi
useradd -r -d /var/lib/kodi kodi
echo enter a password for your kodi user account. This can be changed later from your ssh console with the "passwd" command. This user will have administrative access to this system by default, so please make it difficult to guess.
passwd kodi
echo setting group ownership...
usermod -a -G wheel,audio,video,network,storage,optical,kodi kodi
echo setting kodi user to use bash as login shell...
usermod -s /bin/bash kodi
factory-reset
;;
retroarch)
export nouser=1
if [ $3 = y ];then
export services=`echo "avahi-daemon NetworkManager ntpd sshd swap wifiinit wpa_supplicant"`
else
export services=`echo "avahi-daemon NetworkManager sshd ntpd sshd wifiinit wpa_supplicant"`
fi
for f in "/etc/skel/.zlogin" "/etc/skel/.profile";do
cat > $f <<EOF
source /etc/profile.d/*.sh
umask 077
export GTK_MODULES=gail:atk-bridge
export QT_ACCESSIBILITY=1
export DTK_PROGRAM=espeak
export PATH=$PATH:/opt/android-sdk/platform-tools:/usr/bin/core_perl:~/bin
if [ -f jenux.defaults ];then
dbus-launch gsettings set org.mate.interface accessibility true
cat jenux.defaults|dconf load /
rm jenux.defaults
else
sleep .01
fi
if is-x-running;then
sleep .01
else
startx
logout
fi
EOF
done
echo ratpoison >> /etc/skel/.xinitrc
echo 'exec sh -c "retroarch;killall ratpoison"' >> /etc/skel/.ratpoisonrc
for n in "1" "2" "3" "4" "5" "6";do
mkdir -p /etc/systemd/system/getty@tty$n.service.d
cat >> /etc/systemd/system/getty@tty$n.service.d/retroarch.conf<<EOF
[Service]
ExecStart=-/sbin/agetty -a retroarch --noclear --nohostname --nonewline %I $TERM
EOF
done
useradd -m -r -d /var/lib/retroarch retroarch
echo enter a password for your retroarch user account. This can be changed later from your ssh console with the "passwd" command. This user will have administrative access to this system by default, so please make it difficult to guess.
passwd retroarch
echo setting group ownership...
cp -rf /usr/share/libretro/* /var/lib/retroarch/.config/retroarch
usermod -a -G wheel,audio,video,network,storage,optical,retroarch retroarch
chown -R retroarch:retroarch /var/lib/retroarch
echo setting retroarch user to use bash as login shell...
usermod -s /bin/bash retroarch
;;
all)
if [ $3 = y ];then
export services=`echo "avahi-daemon bluetooth cups-browsed ModemManager NetworkManager org.cups.cupsd swap systemd-timesyncd wifiinit"`
else
export services=`echo "avahi-daemon bluetooth cups-browsed ModemManager NetworkManager org.cups.cupsd systemd-timesyncd wifiinit"`
fi
for f in "/etc/skel/.zlogin" "/etc/skel/.profile";do
cat > $f <<EOF
source /etc/profile.d/*.sh
umask 077
export GTK_MODULES=gail:atk-bridge
export QT_ACCESSIBILITY=1
export DTK_PROGRAM=espeak
export PATH=$PATH:/opt/android-sdk/platform-tools:/usr/bin/core_perl:~/bin
if [ -f jenux.defaults ];then
dbus-launch gsettings set org.mate.interface accessibility true
cat jenux.defaults|dconf load /
rm jenux.defaults
else
sleep .01
fi
if is-x-running;then
sleep .01
else
startx
logout
fi
EOF
done
;;
esac
else
echo GRUB_INIT_TUNE\=\"480 440 4 440 4 440 4 349 3 523 1 440 4 349 3 523 1 440 8 659 4 659 4 659 4 698 3 523 1 415 4 349 3 523 1 440 8\" >> /etc/default/grub
case "$2" in
base)
if [ $3 = y ];then
export services=`echo "avahi-daemon bluetooth fenrirscreenreader NetworkManager ntpd speech-dispatcherd swap wifiinit"`
else
export services=`echo "avahi-daemon bluetooth fenrirscreenreader NetworkManager ntpd speech-dispatcherd wifiinit"`
fi
for f in "/etc/skel/.zlogin" "/etc/skel/.profile";do
cat > $f <<EOF
source /etc/profile.d/*.sh
umask 077
export GTK_MODULES=gail:atk-bridge
export QT_ACCESSIBILITY=1
export DTK_PROGRAM=espeak
sudo speechctl stop
spd-say " "
sudo speechctl start
EOF
done
;;
gnome)
if [ $3 = y ];then
export services=`echo "avahi-daemon bluetooth cups-browsed gdm ModemManager NetworkManager org.cups.cupsd swap systemd-timesyncd wifiinit"`
else
export services=`echo "avahi-daemon bluetooth cups-browsed gdm ModemManager NetworkManager org.cups.cupsd systemd-timesyncd wifiinit"`
fi
if [ -d /var/lib/gdm ];then
echo "fixing speech during gdm login screen"
rm -rf /var/lib/gdm/.local /var/lib/gdm/.config
cp /etc/skel/.libao /var/lib/gdm
mkdir -p /var/lib/gdm/.config/dconf
mkdir -p /var/lib/gdm/.local/share
cp -rf /etc/skel/.local/share/orca /var/lib/gdm/.local/share
mv /etc/skel/.config/dconf/user /var/lib/gdm/.config/dconf
chown -R gdm:gdm /var/lib/gdm
fi
;;
mate)
if [ $3 = y ];then
export services=`echo "avahi-daemon bluetooth fenrirscreenreader NetworkManager ntpd speech-dispatcherd swap wifiinit"`
else
export services=`echo "avahi-daemon bluetooth fenrirscreenreader NetworkManager ntpd speech-dispatcherd wifiinit"`
fi
for f in "/etc/skel/.zlogin" "/etc/skel/.profile";do
cat > $f <<EOF
source /etc/profile.d/*.sh
umask 077
export GTK_MODULES=gail:atk-bridge
export QT_ACCESSIBILITY=1
export DTK_PROGRAM=espeak
export PATH=$PATH:/opt/android-sdk/platform-tools:/usr/bin/core_perl:~/bin
if [ -f jenux.defaults ];then
dbus-launch gsettings set org.mate.interface accessibility true
cat jenux.defaults|dconf load /
rm jenux.defaults
else
sleep .01
fi
if is-x-running;then
sleep .01
else
sudo speechctl stop
spd-say " "
startx
sudo speechctl start
logout
fi
EOF
done
;;
kodi)
export nouser=1
if [ $3 = y ];then
export services=`echo "avahi-daemon kodi NetworkManager ntpd sshd swap wifiinit wpa_supplicant"`
else
export services=`echo "avahi-daemon kodi NetworkManager ntpd sshd wifiinit wpa_supplicant"`
fi
useradd -r -d /var/lib/kodi kodi
echo enter a password for your kodi user account. This can be changed later from your ssh console with the "passwd" command. This user will have administrative access to this system by default, so please make it difficult to guess.
passwd kodi
echo setting group ownership...
usermod -a -G wheel,audio,video,network,storage,optical,kodi kodi
echo setting kodi user to use bash as login shell...
usermod -s /bin/bash kodi
factory-reset
;;
retroarch)
export nouser=1
if [ $3 = y ];then
export services=`echo "avahi-daemon NetworkManager ntpd sshd swap wifiinit wpa_supplicant"`
else
export services=`echo "avahi-daemon NetworkManager retroarch sshd ntpd sshd wifiinit wpa_supplicant"`
fi
rm -rf /etc/skel/.config/retroarch
mv /etc/skel/.config/retroarch.accessibility /etc/skel/.config/retroarch
for f in "/etc/skel/.zlogin" "/etc/skel/.profile";do
cat > $f <<EOF
source /etc/profile.d/*.sh
umask 077
export GTK_MODULES=gail:atk-bridge
export QT_ACCESSIBILITY=1
export DTK_PROGRAM=espeak
export PATH=$PATH:/opt/android-sdk/platform-tools:/usr/bin/core_perl:~/bin
if [ -f jenux.defaults ];then
dbus-launch gsettings set org.mate.interface accessibility true
cat jenux.defaults|dconf load /
rm jenux.defaults
else
sleep .01
fi
if is-x-running;then
sleep .01
else
startx
logout
fi
EOF
done
echo ratpoison >> /etc/skel/.xinitrc
echo 'exec sh -c "retroarch;killall ratpoison"' >> /etc/skel/.ratpoisonrc
for n in "1" "2" "3" "4" "5" "6";do
mkdir -p /etc/systemd/system/getty@tty$n.service.d
cat >> /etc/systemd/system/getty@tty$n.service.d/retroarch.conf<<EOF
[Service]
ExecStart=-/sbin/agetty -a retroarch --noclear --nohostname --nonewline %I $TERM
EOF
done
useradd -m -r -d /var/lib/retroarch retroarch
echo enter a password for your retroarch user account. This can be changed later from your ssh console with the "passwd" command. This user will have administrative access to this system by default, so please make it difficult to guess.
passwd retroarch
echo setting group ownership...
cp -rf /usr/share/libretro/* /var/lib/retroarch/.config/retroarch
usermod -a -G wheel,audio,video,network,storage,optical,retroarch retroarch
chown -R retroarch:retroarch /var/lib/retroarch
echo setting retroarch user to use bash as login shell...
usermod -s /bin/bash retroarch
;;
all)
if [ $3 = y ];then
export services=`echo "avahi-daemon bluetooth cups-browsed fenrirscreenreader ModemManager NetworkManager org.cups.cupsd speech-dispatcherd swap systemd-timesyncd wifiinit"`
else
export services=`echo "avahi-daemon bluetooth cups-browsed fenrirscreenreader ModemManager NetworkManager org.cups.cupsd speech-dispatcherd systemd-timesyncd wifiinit"`
fi
for f in "/etc/skel/.zlogin" "/etc/skel/.profile";do
cat > $f <<EOF
source /etc/profile.d/*.sh
umask 077
export GTK_MODULES=gail:atk-bridge
export QT_ACCESSIBILITY=1
export DTK_PROGRAM=espeak
export PATH=$PATH:/opt/android-sdk/platform-tools:/usr/bin/core_perl:~/bin
if [ -f jenux.defaults ];then
dbus-launch gsettings set org.mate.interface accessibility true
cat jenux.defaults|dconf load /
rm jenux.defaults
else
sleep .01
fi
if is-x-running;then
sleep .01
else
sudo speechctl stop
spd-say " "
startx
sudo speechctl start
logout
fi
EOF
done
;;
esac
fi
if [ $nouser = 1 ];then
sleep .01
else
while true;do
echo "enter your login name."
read user
if useradd -m -s /usr/bin/zsh -u 1005 $user;then
break
else
echo "error adding user, please reenter your login name."
continue
fi
done
while true;do
echo "enter a password that you will use to log in. Note:  your password must be 64 characters or less in order for the file encryption to work propperly. "
if passwd $user;then
break
else
continue
fi
done
echo "Enter your information so that the system can identify you. All info is not required, but as a recommendation, you should at least enter your name. "
chfn $user
while true;do
echo "encrypting your home directory... At the passphrase prompt, enter your login password. "
if ecryptfs-migrate-home -u $user;then
rm -rf /home/$user.*
break
else
rm -rf /home/.ecryptfs
continue
fi
done
usermod -a -G wheel,audio,video,optical,network,dbus,floppy,storage,scanner,input,speech $user
fi
if df -h /|tail -n 1|cut -f 1 -d \  |grep -q /dev/mapper;then
echo "root is encrypted, regenerating initcpios..."
mv /etc/mkinitcpio.conf.encrypted /etc/mkinitcpio.conf
mv /etc/default/grub.encrypted /etc/default/grub
cd /etc/mkinitcpio.d
for preset in `ls *.preset|cut -f 1 -d .`;do
mkinitcpio -p $preset
done
else
echo "Root is not encrypted, using system installed initcpios..."
rm /etc/mkinitcpio.conf.encrypted /etc/default/grub.encrypted
fi
cd /
echo "installing grub boot loader... "
export disk=$1
grub-install --target i386-pc $disk
grub-install --efi-directory /boot --target i386-efi $disk
grub-install --efi-directory /boot --target x86_64-efi $disk
mv /boot/EFI/arch/ /boot/EFI/boot
mv /boot/EFI/boot/grubia32.efi /boot/EFI/boot/bootia32.efi
mv /boot/EFI/boot/grubx64.efi /boot/EFI/boot/loader.efi
cp /usr/share/preloader-signed/HashTool.efi  /boot/EFI/boot
cp /usr/share/preloader-signed/PreLoader.efi  /boot/EFI/boot/bootx64.efi
echo "making bootloader configuration file... "
grub-mkconfig -o /boot/grub/grub.cfg
echo "Default system time will be in UTC, set to your desired timezone in your desktop environment or by running: ln -s /usr/share/zoneinfo/timezone_designation, such as /usr/share/zoneinfo/America/New_York."
echo "generating system locale definitions"
locale-gen
echo "enabling services"
for s in `echo $services`;do
if [ -f /usr/lib/systemd/system/$s.service ];then
systemctl enable $s
fi
done
echo "complete! your system is set up and ready for you to use! Enjoy your jenux system! "
rm /etc/postinstall.sh
umount /sys/firmware/efi/efivars /sys /dev /proc
exit 0
