#! /usr/bin/env python

from __future__ import print_function
import os
import json
import socket
import uuid
import hashlib

import yaml
import cherrypy
import requests

try:
	from urllib.parse import quote
except ImportError:
	from urllib import quote

import alexapi.config

with open(alexapi.config.filename, 'r') as stream:
	config = yaml.load(stream)


class Start(object):

	def index(self):
		sd = json.dumps({
			"alexa:all": {
				"productID": config['alexa']['Device_Type_ID'],
				"productInstanceAttributes": {
					"deviceSerialNumber": hashlib.sha256(str(uuid.getnode()).encode()).hexdigest()
				}
			}
		})

		url = "https://www.amazon.com/ap/oa"
		callback = cherrypy.url() + "code"
		payload = {
			"client_id": config['alexa']['Client_ID'],
			"scope": "alexa:all",
			"scope_data": sd,
			"response_type": "code",
			"redirect_uri": callback
		}
		req = requests.Request('GET', url, params=payload)
		prepared_req = req.prepare()
		raise cherrypy.HTTPRedirect(prepared_req.url)

	def code(self, var=None, **params):		# pylint: disable=unused-argument
		code = quote(cherrypy.request.params['code'])
		callback = cherrypy.url()
		payload = {
			"client_id": config['alexa']['Client_ID'],
			"client_secret": config['alexa']['Client_Secret'],
			"code": code,
			"grant_type": "authorization_code",
			"redirect_uri": callback
		}
		url = "https://api.amazon.com/auth/o2/token"
		response = requests.post(url, data=payload)
		resp = response.json()

		alexapi.config.set_variable(['alexa', 'refresh_token'], resp['refresh_token'])
		print("Success!")
		quit()

	index.exposed = True
	code.exposed = True

cherrypy.config.update({'server.socket_host': '0.0.0.0'})
cherrypy.config.update({'server.socket_port': int(os.environ.get('PORT', '5050'))})
cherrypy.config.update({"environment": "embedded"})


ip = [(s.connect(('8.8.8.8', 53)), s.getsockname()[0], s.close()) for s in [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1]
print("Alexa authorization server Ready. In a web browser, go to the following address: http://{}:5050 to link this device to your amazon account. Please Note: as long as you see Success on your device's display, the authorization process has succeeded. Please disregard any server not found messages after signing in through your browser. ".format(ip))
cherrypy.quickstart(Start())
